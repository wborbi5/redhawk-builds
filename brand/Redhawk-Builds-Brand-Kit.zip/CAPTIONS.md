# Copy for the rebuilt campaign

Replace TYPEFORM_URL and add the appropriate native registration action before publishing. Do not post “link in bio” until the bio link is correct.

## 01 — Announce

Redhawk Builds. A fintech build weekend at Miami.

Learn Friday. Build Saturday. Pitch Sunday.

Join business, data science, and CS students at McVey, Nov 6–8, 2026. Teams of 3–5. First-time builders welcome.

Register through Typeform at the link in bio.

Alt text: Redhawk Builds in large white lettering on Ink. A fintech build weekend at Miami University, Nov 6–8, 2026. Learn Friday, build Saturday, pitch Sunday. McVey Data Science Building, Oxford, Ohio.

## 02 — Business meets builders

Know the financial problem? Good at explaining a business model? Can turn an idea into a demo?

There’s a place for each of those skills on a Redhawk Builds team.

Bring your perspective. Work in a team of 3–5. Build around one of 30 written fintech problems.

Nov 6–8 · McVey · Miami students. Register through the link in bio.

Alt text: “You know the problem. They can build it.” Redhawk Builds brings finance, business, data science, and CS students together in teams of 3–5, Nov 6–8 at McVey.

## 03 — Prizes

Build something worth showing.

First place: $2,000. Second: $1,000. Third: $500. Plus sponsor Best Use prizes.

The demo matters—and so do the problem, fintech context, business model, data/APIs, and pitch.

Redhawk Builds · Nov 6–8, 2026 · McVey. Register through the link in bio.

Alt text: Redhawk Builds podium prizes: $2,000 first place, $1,000 second, and $500 third, shown in green. Sponsor Best Use prizes are additional.

## 04 — The weekend

Friday: learn. Check in at 6 PM.
Saturday: build. The clock starts at 10 AM.
Sunday: pitch. Submissions lock at 10 AM; finals follow, with timing to be announced.

Your build window is 24 hours. The weekend gives you time to learn before it starts.

Nov 6–8, 2026 · McVey Data Science Building · Miami University. All times Eastern. Registration: link in bio.

Alt text: Three-day Redhawk Builds schedule. Friday Nov 6, check-in at 6 PM. Saturday Nov 7, build begins at 10 AM. Sunday Nov 8, submission lock at 10 AM; finals timing to be announced. All times Eastern.

## 05 — First-timers

First hackathon? You belong here.

You don’t need a finished idea or a CS major. Start with 30 written fintech problems, learn with other Miami students, and build in a team of 3–5.

Come curious.

Redhawk Builds · Nov 6–8 · McVey. Register through the link in bio.

Alt text: “First hackathon?” in large white type. No finished idea or CS major required. Thirty written fintech problems, teams of 3–5, and first-time builders welcome. Redhawk Builds, Nov 6–8, 2026.

## Stories

06: Add a native link sticker labeled **Register for Redhawk Builds**, pointing to TYPEFORM_URL.

07: Add a native link sticker labeled **Join the weekend**, pointing to TYPEFORM_URL.

Keep stickers clear of the event copy and out of the top/bottom interface zones. The PNG itself does not contain a clickable link.

## Event cover / Luma

Title: **Redhawk Builds ($RHB)**

Description: **A fintech build weekend for Miami University students. Learn Friday, build Saturday, pitch Sunday. Teams of 3–5 work from 30 written fintech problems. First-time builders welcome. Nov 6–8, 2026, at McVey Data Science Building, Oxford, Ohio.**

Registration note: **Complete Typeform to register: TYPEFORM_URL. A Luma RSVP alone is not registration.**

Hosts: Sigma Eta Pi (SEPi), Miami Banking Club, RedHawk Applied AI.

## Share card

Title: **Redhawk Builds · Nov 6–8, 2026**

Description: **A fintech build weekend at Miami. Learn Friday. Build Saturday. Pitch Sunday. First-time builders welcome.**

## Copy guardrails

Use plain verbs and concrete details. Avoid “unlock,” “revolutionize,” “seamless,” and “next-gen.” Do not imply AWS or university sponsorship, guaranteed seating, or unconfirmed perks. Keep registration claims aligned with Typeform.
