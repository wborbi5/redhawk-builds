"""Run from any directory. Requires reportlab. SVG exports embed the bundled fonts."""
from pathlib import Path
import base64,html,json
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'campaign';OUT.mkdir(exist_ok=True)
fonts={'Display':'BarlowCondensed-ExtraBold.ttf','Body':'DMSans-Regular.ttf','Label':'DMSans-SemiBold.ttf'}
css=''
for name,file in fonts.items():
    data=(ROOT/'fonts'/file).read_bytes();pdfmetrics.registerFont(TTFont(name,str(ROOT/'fonts'/file)))
    css+=f"@font-face{{font-family:{name};src:url(data:font/ttf;base64,{base64.b64encode(data).decode()}) format('truetype');}}"
INK='#0B0D12'; SURFACE='#1C1F26'; RED='#E0453F'; GREEN='#00D47E'; GRAY='#8A8F98'; WHITE='#FFFFFF'; PAPER='#F4EFE6'
manifest=[]
class Art:
    def __init__(self,name,w=1080,h=1350,light=False):
        self.name=name;self.w=w;self.h=h;self.light=light;self.fg=INK if light else WHITE;self.red='#B3202F' if light else RED;self.green='#1F8A5B' if light else GREEN
        self.parts=[f'<rect width="{w}" height="{h}" fill="{PAPER if light else INK}"/>']
    def rect(self,x,y,w,h,color):self.parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{color}"/>');return self
    def text(self,x,y,s,size=30,font='Body',color=None,width=None,anchor='start'):
        if width:size=min(size,width/pdfmetrics.stringWidth(s,font,1))
        self.parts.append(f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="{font}" font-size="{size:.3f}" fill="{color or self.fg}">{html.escape(s)}</text>');return self
    def line(self,y,x=64,end=None):self.parts.append(f'<path d="M{x} {y} H{end or self.w-64}" stroke="{ "#C8C4BB" if self.light else "#353840" }" stroke-width="2"/>');return self
    def top(self,label='MIAMI UNIVERSITY',right='NOV 6–8, 2026'):
        self.rect(64,64,10,28,self.red).text(92,88,label,24,'Label');self.text(self.w-64,88,right,24,'Label',anchor='end');return self
    def footer(self,top=1150):
        self.line(top).text(64,top+54,'McVey Data Science Building',30,'Label').text(64,top+96,'Miami University · Oxford, OH',25)
        self.text(self.w-64,top+54,'$RHB',29,'Display',anchor='end').text(self.w-64,top+96,'LONG OXFORD.',19,'Label',anchor='end');return self
    def save(self):
        (OUT/(self.name+'.svg')).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" viewBox="0 0 {self.w} {self.h}"><defs><style>{css}</style></defs>'+''.join(self.parts)+'</svg>',encoding='utf-8')
        manifest.append({'file':self.name,'width':self.w,'height':self.h})

a=Art('01-launch');a.top();a.text(55,343,'REDHAWK',264,'Display',width=958).text(55,571,'BUILDS',286,'Display',width=958)
a.text(67,665,'A FINTECH BUILD WEEKEND.',53,'Display').rect(64,729,952,85,RED).text(88,786,'LEARN FRIDAY. BUILD SATURDAY. PITCH SUNDAY.',38,'Display',INK,width=904)
a.text(64,914,'Business minds. Technical builders.',35,'Label').text(64,966,'One weekend to make something work.',33)
a.text(64,1070,'FIRST-TIME BUILDERS WELCOME',26,'Label');a.footer();a.save()

a=Art('02-business-meets-builders');a.top('BUSINESS + BUILDERS');a.text(64,244,'YOU KNOW',142,'Display').text(64,385,'THE PROBLEM.',151,'Display',width=944)
a.rect(64,439,952,3,RED).text(64,592,'THEY CAN',142,'Display').text(64,733,'BUILD IT.',168,'Display')
a.text(64,850,'Find your people at Redhawk Builds.',36,'Label').text(64,908,'Finance, business, data science, and CS.',30)
a.rect(64,966,952,118,SURFACE).text(90,1017,'TEAMS OF 3–5',30,'Display').text(90,1060,'Different skills. One working demo.',29);a.footer();a.save()

a=Art('03-prizes');a.top('REDHAWK BUILDS');a.text(64,244,'BUILD SOMETHING',106,'Display',width=952).text(64,358,'WORTH SHOWING.',125,'Display',width=952)
a.text(67,457,'FIRST PLACE',26,'Label').text(51,689,'$2,000',263,'Display',GREEN,width=974)
a.line(756).text(64,823,'SECOND PLACE',25,'Label').text(64,954,'$1,000',139,'Display',GREEN).text(604,823,'THIRD PLACE',25,'Label').text(604,954,'$500',139,'Display',GREEN)
a.text(64,1072,'Plus sponsor Best Use prizes.',32);a.footer();a.save()

a=Art('04-weekend');a.top('REDHAWK BUILDS');a.text(64,250,'MAKE A WEEKEND OF IT.',93,'Display',width=952)
for y,day,date,title,time,desc in [(351,'FRI','06','LEARN.','6 PM CHECK-IN','Meet the room. Get ready to build.'),(612,'SAT','07','BUILD.','10 AM BUILD START','Turn a fintech problem into a demo.'),(873,'SUN','08','PITCH.','10 AM SUBMISSION LOCK','Finals follow. Time to be announced.')]:
    a.line(y-44);a.text(64,y+6,day,33,'Display').text(58,y+132,date,153,'Display');a.text(291,y+55,title,103,'Display').text(296,y+109,time,24,'Label').text(296,y+154,desc,26,width=715)
a.footer(1150);a.save()

a=Art('05-first-timers');a.top('YOUR FIRST BUILD COUNTS.');a.text(64,302,'FIRST',211,'Display').text(64,514,'HACKATHON?',190,'Display',width=952)
a.text(64,650,'You don’t need a finished idea.',37,'Label').text(64,708,'You don’t need to be a CS major.',37,'Label')
a.text(64,801,'Start with 30 written fintech problems.',31).text(64,854,'Learn with other Miami students.',31).text(64,907,'Build in a team of 3–5.',31)
a.rect(64,978,952,109,RED).text(98,1053,'COME CURIOUS.',64,'Display',INK);a.footer();a.save()

a=Art('06-story-register',1080,1920);a.text(64,307,'MIAMI UNIVERSITY / NOV 6–8, 2026',26,'Label').text(54,572,'REDHAWK',264,'Display',width=958).text(54,800,'BUILDS',286,'Display')
a.rect(64,867,952,80,RED).text(91,923,'A FINTECH BUILD WEEKEND.',46,'Display',INK)
a.text(64,1057,'Learn Friday.',70,'Display').text(64,1137,'Build Saturday.',70,'Display').text(64,1217,'Pitch Sunday.',70,'Display')
a.text(64,1337,'First-time builders welcome.',34,'Label').text(64,1390,'McVey · Miami University · Oxford, OH',28)
a.text(64,1597,'REGISTER THROUGH TYPEFORM',27,'Label');a.line(1660);a.save()

a=Art('07-story-prizes',1080,1920);a.text(64,307,'REDHAWK BUILDS / NOV 6–8, 2026',26,'Label').text(64,510,'BRING YOUR',162,'Display').text(64,675,'BEST BUILD.',172,'Display',width=952)
a.text(52,971,'$3,500',271,'Display',GREEN,width=974).text(64,1060,'IN PODIUM PRIZES',41,'Display').text(64,1156,'Plus sponsor Best Use prizes.',32)
a.line(1253).text(64,1370,'Business + data science + CS',34,'Label').text(64,1430,'Your first build counts.',34)
a.text(64,1597,'REGISTER THROUGH TYPEFORM',27,'Label');a.line(1660);a.save()

a=Art('08-event-cover',1920,1080);a.top('MIAMI UNIVERSITY', 'NOV 6–8, 2026 / OXFORD, OH')
a.text(53,363,'REDHAWK',298,'Display',width=1080).text(53,647,'BUILDS',343,'Display',width=1080)
a.rect(1215,192,3,560,RED).text(1270,306,'LEARN.',115,'Display').text(1270,362,'FRIDAY',25,'Label').text(1270,491,'BUILD.',115,'Display').text(1270,547,'SATURDAY',25,'Label').text(1270,676,'PITCH.',115,'Display').text(1270,732,'SUNDAY',25,'Label')
a.text(64,780,'A fintech build weekend. First-time builders welcome.',39,'Label');a.line(870).text(64,941,'McVey Data Science Building · Miami University',32,'Label').text(64,996,'Sigma Eta Pi · Miami Banking Club · RedHawk Applied AI',25);a.text(1856,987,'$RHB',43,'Display',anchor='end');a.save()

a=Art('09-share-card',1200,630);a.text(50,64,'MIAMI UNIVERSITY',20,'Label').text(1150,64,'NOV 6–8, 2026',23,'Label',anchor='end')
a.text(43,267,'REDHAWK',210,'Display',width=1050).text(43,458,'BUILDS',224,'Display',width=770).rect(838,318,310,111,RED).text(867,391,'COME CURIOUS.',37,'Display',INK,width=253)
a.line(512,50,1150).text(50,558,'A fintech build weekend at McVey.',28,'Label').text(50,603,'Learn Friday. Build Saturday. Pitch Sunday.',22);a.save()

a=Art('10-print-poster',1650,2550,True);a.rect(100,104,14,37,a.red).text(139,139,'MIAMI UNIVERSITY',38,'Label').text(1550,139,'NOV 6–8, 2026',40,'Label',anchor='end')
a.text(80,550,'REDHAWK',412,'Display',width=1480).text(80,914,'BUILDS',457,'Display')
a.text(100,1085,'A FINTECH BUILD WEEKEND.',99,'Display').line(1180,100,1550)
for y,word,day in [(1358,'LEARN.','FRIDAY'),(1543,'BUILD.','SATURDAY'),(1728,'PITCH.','SUNDAY')]:a.text(100,y,word,157,'Display').text(850,y-24,day,44,'Label')
a.text(100,1920,'First-time builders welcome.',53,'Label').text(100,2001,'Business + data science + CS. Teams of 3–5.',41)
a.line(2110,100,1550).text(100,2200,'McVey Data Science Building',48,'Label').text(100,2262,'Miami University · Oxford, OH',38).text(100,2390,'REGISTER THROUGH TYPEFORM',37,'Label',a.red).text(1550,2390,'$RHB',62,'Display',anchor='end');a.save()

(ROOT/'asset-manifest.json').write_text(json.dumps(manifest,indent=2))
print(f'{len(manifest)} new campaign designs generated.')
