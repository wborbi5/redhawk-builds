"""Build the PDF after rendering the campaign SVG files to PNG. Requires reportlab."""
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor

ROOT=Path(__file__).resolve().parents[1]
for n,f in [('Display','BarlowCondensed-ExtraBold.ttf'),('Body','DMSans-Regular.ttf'),('Label','DMSans-SemiBold.ttf')]:pdfmetrics.registerFont(TTFont(n,str(ROOT/'fonts'/f)))
I='#0B0D12';S='#1C1F26';R='#E0453F';G='#00D47E';C='#8A8F98';W='#FFFFFF';P='#F4EFE6';D='#4B5058';RL='#B3202F';GL='#1F8A5B'
c=canvas.Canvas(str(ROOT/'Redhawk-Builds-Brand-Playbook.pdf'),pagesize=(1000,700));c.setTitle('Redhawk Builds | Brand Playbook');c.setAuthor('Redhawk Builds')
light=False
def rect(x,y,w,h,col):c.setFillColor(HexColor(col));c.rect(x,700-y-h,w,h,fill=1,stroke=0)
def tx(x,y,s,size=14,font='Body',col=None):
    c.setFillColor(HexColor(col or (I if light else W)));c.setFont(font,size);c.drawString(x,700-y,s)
def para(x,y,s,width=380,size=15,col=None,leading=23):
    words=s.split();line='';lines=[]
    for word in words:
        test=(line+' '+word).strip()
        if pdfmetrics.stringWidth(test,'Body',size)>width:lines.append(line);line=word
        else:line=test
    lines.append(line)
    for i,v in enumerate(lines):tx(x,y+i*leading,v,size,col=col or (D if light else C))
    return y+len(lines)*leading
def line(y,x=50,w=900):rect(x,y,w,1,'#C8C4BB' if light else '#353840')
def page(n,label,title='',islight=False):
    global light;light=islight;rect(0,0,1000,700,P if light else I)
    rect(50,33,5,18,RL if light else R);tx(66,47,'REDHAWK BUILDS',12,'Label');tx(758,47,'BRAND PLAYBOOK / '+str(n).zfill(2),10,'Label')
    tx(50,106,label,11,'Label',RL if light else R)
    if title:tx(50,169,title,54,'Display')
def end():
    line(653);tx(50,680,'CAMPAIGN SYSTEM / SEPTEMBER 2026',9,'Label',D if light else C);tx(706,680,'MIAMI UNIVERSITY / OXFORD, OH',9,'Label',D if light else C);c.showPage()
def image(file,x,y,w,h):c.drawImage(str(ROOT/'campaign'/file),x,700-y-h,width=w,height=h,mask='auto',preserveAspectRatio=True,anchor='c')

page(1,'COME CURIOUS.')
tx(43,292,'REDHAWK',189,'Display');tx(43,465,'BUILDS',210,'Display')
rect(50,506,900,51,R);tx(69,542,'A FINTECH BUILD WEEKEND.',31,'Display',I)
tx(50,607,'NOV 6-8, 2026',24,'Label');tx(374,607,'McVey Data Science Building',22,'Body');end()

page(2,'POSITIONING','MAKE IT ABOUT THE WEEKEND.',True)
para(50,218,'A student should know what this is, who belongs, and why to come before they notice a finance reference.',427,20,I,leading=28)
for y,num,head,body in [(354,'01','A real thing to make','A working demo, built around a fintech problem.'),(443,'02','People worth meeting','Business, data science, and CS in the same team.'),(532,'03','A place to start','Education first. First-time builders welcome.')]:
    tx(50,y,num,24,'Display');tx(101,y,head,20,'Label');para(101,y+27,body,375,14,leading=20)
image('01-launch.png',548,222,184,230);image('05-first-timers.png',754,322,184,230);end()

page(3,'NEW TYPOGRAPHY','LOUD HEADLINES. HUMAN COPY.')
tx(50,247,'BARLOW CONDENSED',72,'Display');tx(50,314,'EXTRABOLD',72,'Display')
tx(50,367,'ABCDEFGHIJKLM  0123456789  $',34,'Display',C)
line(401)
tx(50,447,'DM Sans',36,'Label');tx(50,481,'Regular / SemiBold',17,'Body',C)
para(50,527,'Body copy, dates, logistics, and short labels. Readable language with enough size to survive a phone screen.',410,16)
para(565,442,'Barlow Condensed replaces the former mono headline system. Its compact width gives the event name scale without reducing the supporting details to tiny labels.',384,16)
para(565,555,'Use display type for major prize figures. Use DM Sans for everyday numbers. JetBrains Mono is no longer part of this campaign kit.',384,14)
end()

page(4,'COLOR ROLES','SAME MEANING. MORE DISCIPLINE.',True)
swatches=[('INK',I,'Base'),('SURFACE',S,'Support'),('BRICK',R,'Brand / CTA'),('SIGNAL',G,'Money'),('PAPER',P,'Print / light')]
for j,(name,color,role) in enumerate(swatches):
    x=50+j*181;rect(x,215,158,80,color);tx(x,324,name,14,'Label');tx(x,350,color,13,'Label',D);tx(x,376,role,13,'Body',D)
line(407)
rect(50,439,276,130,I);tx(69,475,'REGISTER',18,'Display',R);tx(69,531,'NOV 6-8',43,'Display',W)
rect(360,439,276,130,I);tx(379,475,'FIRST PLACE',12,'Label',C);tx(375,541,'$2,000',66,'Display',G)
tx(676,465,'LIGHT VARIANTS',13,'Label',RL);tx(676,497,'Brick: #B3202F',14,'Label');tx(676,526,'Signal: #1F8A5B',14,'Label');tx(676,555,'Code gray: #8A8F98',14,'Label')
tx(50,610,'Never color a number red. Green is money, not decoration. White is the dark-mode text utility.',15,'Label');end()

page(5,'IDENTITY HANDLING','THE NAME DOES THE WORK.')
rect(50,222,454,357,S);tx(75,355,'REDHAWK',106,'Display');tx(75,472,'BUILDS',135,'Display');tx(79,547,'CAMPAIGN TITLE TREATMENT',13,'Label',C)
tx(555,245,'Use the full event name first.',23,'Label');para(555,285,'This is a typeset campaign title, not a recreation of the missing primary logo. Keep its two lines aligned left and give it clear space.',390,15)
tx(555,405,'Keep $RHB as a signature.',23,'Label');para(555,445,'The ticker belongs in a footer, supporting label, or finance-specific application. The opening price remains 18.09. It does not need to lead every asset.',390,15)
para(50,618,'Supplied logos remain untouched. No Miami M, RedHawks, Farmer, AWS, or host marks are invented.',890,13,W,leading=18);end()

page(6,'LAYOUT','ONE MESSAGE PER ASSET.',True)
for x,f in [(50,'01-launch.png'),(356,'03-prizes.png'),(662,'04-weekend.png')]:image(f,x,212,264,330)
for x,title,desc in [(50,'ANNOUNCE','Make the event name unmistakable.'),(356,'MOTIVATE','Show the money, with the actual amounts.'),(662,'EXPLAIN','Give the weekend a simple rhythm.')]:
    tx(x,574,title,21,'Display');para(x,600,desc,260,13,leading=18)
end()

page(7,'COPY & ENGAGEMENT','GIVE THEM A REASON TO CARE.')
tx(50,245,'FIRST HACKATHON?',68,'Display');tx(50,294,'You don\'t need a finished idea.',25,'Label');tx(50,333,'You don\'t need to be a CS major.',25,'Label')
line(378)
tx(50,422,'SAY WHAT THEY GET',15,'Label',R);para(50,458,'A team, a fintech problem, a learning day, and time to build a working demo. Concrete details beat promises about changing the world.',405,16)
tx(550,422,'MAKE THE NEXT STEP CLEAR',15,'Label',R);para(550,458,'Use one registration action: Typeform. Pair feed posts with a working bio link and stories with a native link sticker. Luma RSVP is not registration.',396,16)
para(50,601,'Judge engagement by completed registrations and useful replies. These designs are a stronger direction, not a guarantee of performance.',883,13,W,leading=19);end()

page(8,'PHOTOGRAPHY & GRAPHICS','REAL PEOPLE. REAL WORK.',True)
tx(50,233,'WHEN PHOTOS ARE AVAILABLE',23,'Label');para(50,274,'Use permission-cleared photos of Miami students discussing a problem, building together, or showing a demo. Prioritize faces, hands, and something being made.',410,17,leading=26)
tx(50,444,'UNTIL THEN',23,'Label');para(50,485,'Use strong typography. Do not pass generated event photos, fictional rooms, or generic desk still lifes off as this community.',410,17,leading=26)
tx(550,233,'A SHOT LIST FOR THE EVENT',23,'Label')
for y,t in [(281,'A team explaining an idea to each other.'),(328,'A close view of a real working demo.'),(375,'Friday learning: speaker and audience.'),(422,'A pitch with people listening.'),(469,'A wide room photograph with energy.')]:para(550,y,t,391,16,leading=23)
para(550,562,'The supplied campus thumbnail is too small for a full-size campaign photo. Request its original rather than enlarging it.',391,13,leading=20);end()

page(9,'DELIVERABLES','BUILT FOR THE PLACES IT GOES.')
image('08-event-cover.png',50,211,535,301);image('06-story-register.png',646,211,190,338)
tx(50,548,'COVER / 1920 x 1080',15,'Label');tx(646,581,'STORY / 1080 x 1920',13,'Label')
para(50,586,'Five feed posts, two stories, an event cover, a share card, and a print poster. Every design includes editable SVG and ready-to-place PNG.',535,14,leading=21)
para(646,615,'Keep native link stickers above the platform UI.',302,12,leading=18);end()

page(10,'RELEASE CHECK','MAKE IT READY. THEN SHARE.',True)
items=[('TYPE','Barlow Condensed ExtraBold + DM Sans. No mono-heavy headlines.'),('FACTS','Nov 6-8, 2026. McVey. Miami students. Teams of 3-5.'),('COLOR','No red numbers. Green money only. Paper only in light/print.'),('LOGOS','Original artwork only. Never imply an unconfirmed sponsor.'),('LINKS','Connect the Typeform CTA. Add the actual story link sticker.'),('QUALITY','Check phone-size readability, platform crop, and image alt text.'),('OPS','Devpost for submissions; GroupMe for event operations.')]
for i,(label,desc) in enumerate(items):
    y=229+i*48;tx(50,y,label,13,'Label',RL);para(188,y,desc,743,15,I,leading=21)
line(582);para(50,617,'This revision applies to the brand guide and campaign images only. The live website remains unchanged. Original logo files and final registration links are still pending.',900,12,D,leading=18);end()
c.save();print('10-page visual brand playbook created.')
