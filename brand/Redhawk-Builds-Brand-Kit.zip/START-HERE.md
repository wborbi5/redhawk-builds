# Redhawk Builds — rebuilt campaign kit

This is the revised brand guide and image system. It replaces the earlier mono-heavy campaign direction. The live website, GitHub repository, and email draft were not modified.

## What changed

- **Barlow Condensed ExtraBold** replaces JetBrains Mono in campaign headlines and major prize figures.
- **DM Sans Regular / SemiBold** replaces Inter in campaign body copy, dates, and labels.
- Redhawk Builds is the main identifier. $RHB is a supporting signature.
- Each asset has a job: introduce the event, recruit complementary teammates, explain prizes, show the schedule, or welcome first-timers.
- The kit uses precise typography and real event details. No generated photographs, stock-price sculptures, or simulated trading dashboards are included.
- The practical builder-event reference informs clarity and participation. There is no claim of AWS affiliation or sponsorship.

Your latest instruction to change the typeface overrides the original font lock for this kit. The locked event facts and color meanings remain in place.

## Files

`Redhawk-Builds-Brand-Playbook.pdf` — ten visual pages covering positioning, typography, color, identity handling, layout, copy, photography, formats, and release QA.

`campaign/` — ten finished designs, each in editable SVG and PNG:

| File | Purpose | Size |
|---|---|---|
| 01-launch | Main announcement | 1080 × 1350 |
| 02-business-meets-builders | Team and audience invitation | 1080 × 1350 |
| 03-prizes | Exact podium amounts | 1080 × 1350 |
| 04-weekend | Learn / Build / Pitch schedule | 1080 × 1350 |
| 05-first-timers | First-time builder welcome | 1080 × 1350 |
| 06-story-register | Registration story | 1080 × 1920 |
| 07-story-prizes | Prize story | 1080 × 1920 |
| 08-event-cover | Luma / event cover | 1920 × 1080 |
| 09-share-card | Open Graph / link sharing | 1200 × 630 |
| 10-print-poster | Light print layout | 1650 × 2550 |

`CAPTIONS.md` — ready-to-edit captions, story sticker labels, alt text, and channel instructions.

`fonts/` — the exact font files plus their open font licenses. Install the fonts if your design application does not preserve embedded SVG fonts.

`source/` — Python generators for the campaign SVGs and guide. Requires ReportLab. Run `python source/build_campaign.py` to regenerate SVGs. Export those SVGs to PNG in a browser or design tool, then run `python source/build_guide.py` to regenerate the PDF.

## Practical layout rules

- Feed posts: 64 px outer margins; headlines 100–280 px depending on length; body generally 26–37 px. Keep the event date readable.
- Stories: essential text begins below the top 250 px. The last CTA sits above the bottom 250 px. Place a native Typeform link sticker in the available lower-middle area without covering copy.
- Event cover: use the supplied landscape layout. Do not auto-crop a portrait post into a cover.
- Print: SVG is the scalable master. The PNG corresponds to 11 × 17 inches at 150 ppi; for larger or professional production, export the SVG to PDF at the final print size with fonts embedded. No bleed or printer-specific color conversion is included.
- Dark text: use white for primary copy and Code gray for secondary copy. On Paper, use Ink or the darker print text utility #4B5058; Code gray is too weak for small print text.
- Numbers never use red. Green is reserved for money. Preserve original supplied logos without effects or distortion.

## Before posting

Replace TYPEFORM_URL in the caption deck and put the real registration destination in your bio or story sticker. The exported posters intentionally do not contain a fake URL or QR code. Platform actions must be added in the publishing interface.

The print poster needs a real registration URL or QR added before physical distribution. Its current registration line specifies the platform only.

Use original logo files when they arrive. The current campaign title is live text, not a recreated official logo. University and host marks have not been invented. The green app icon remains a supplied-logo exception to the money-only rule and is not redesigned here.

Finals time is unconfirmed and labeled accordingly. All schedule times refer to Oxford, Ohio, Eastern Time. No free food, guaranteed seating, free admission, or sponsor benefits have been promised.

## Verification

All ten SVGs were rendered at their target dimensions. Text boundaries were checked and no red numerals were detected. All ten guide pages were rendered and visually reviewed. The designs are a new creative direction; engagement should be evaluated through actual audience response and completed Typeform registrations.
